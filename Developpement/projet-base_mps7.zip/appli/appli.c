/*
 * appli.c
 *
 *  Created on: 08/2015
 *      Author: S. Poiraud
 */
#include "appli.h"
#include "stm32f4xx_hal.h"
#include "stm32f4_gpio.h"
#include "stm32f4_uart.h"
#include "stm32f4_timer.h"
#include "stm32f4_sys.h"
#include "macro_types.h"


#define GREEN_LED	GPIOD, GPIO_PIN_12
#define BLUE_LED	GPIOD, GPIO_PIN_15
#define BLUE_BUTTON	GPIOA, GPIO_PIN_0

//////////////////////////////////////

/*
 * Initialisation de notre application, et des p�riph�riques qu'elle utilise
 */
void APPLI_init(void)
{
	GPIO_Configure();	//Configuration des broches d'entree-sortie.

	UART_init(6);	//Initialisation de l'USART6 (PC6=Tx, PC7=Rx, 115200 bauds/sec)
	SYS_set_std_usart(USART6,USART6,USART6);

	//Configuration des ports des LEDS en sortie
	BSP_GPIO_PinCfg(GREEN_LED, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, GPIO_SPEED_FAST, 0);
	BSP_GPIO_PinCfg(BLUE_LED, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL, GPIO_SPEED_FAST, 0);

	//Configuration du port du bouton bleu en entr�e
	BSP_GPIO_PinCfg(GPIOA, GPIO_PIN_0, GPIO_MODE_INPUT, GPIO_NOPULL, GPIO_SPEED_FAST, 0);
}


/*
 * @brief Boucle de t�che de fond de l'application
 * @pre : doit �tre appel�e r�guli�rement.
 */
void APPLI_process_main(void)
{
	bool_e blue, green;

	green = TRUE;
	if(HAL_GPIO_ReadPin(BLUE_BUTTON))
		blue = TRUE;
	else
		blue = FALSE;

	HAL_GPIO_WritePin(GREEN_LED, green);
	HAL_GPIO_WritePin(BLUE_LED, blue);
}

